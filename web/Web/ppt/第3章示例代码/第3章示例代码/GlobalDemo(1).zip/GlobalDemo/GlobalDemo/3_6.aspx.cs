﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _3_6 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("当前网页虚拟路径：" + Request.ServerVariables["URL"] + "<Br>");
        Response.Write("实际路径：" + Request.ServerVariables["PATH_TRANSLATED"] + "<Br>");
        Response.Write("服务器名或IP：" + Request.ServerVariables["SERVER_NAME"] + "<Br>");
        Response.Write("软件：" + Request.ServerVariables["SERVER_SOFTWARE"] + "<Br>");
        Response.Write("服务器连接端口：" + Request.ServerVariables["SERVER_PORT"] + "<Br>");
        Response.Write("HTTP版本：" + Request.ServerVariables["SERVER_PROTOCOL"] + "<Br>");
        Response.Write("客户主机名：" + Request.ServerVariables["REMOTE_HOST"] + "<Br>");
        Response.Write("浏览器：" + Request.ServerVariables["HTTP_USER_AGENT"] + "<Br>");

    }
}
