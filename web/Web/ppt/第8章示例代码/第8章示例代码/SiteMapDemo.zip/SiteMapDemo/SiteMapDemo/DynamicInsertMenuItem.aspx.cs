﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DynamicInsertMenuItem : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        MenuItem homeItem = new MenuItem();
        homeItem.Text = "首页";
        homeItem.ToolTip = "网站的首页";
        Menu1.Items.Add(homeItem);
        MenuItem productItem = new MenuItem("产品分类");
        Menu1.Items.Add(productItem);
        productItem.ChildItems.Add(new MenuItem("硬件产品"));
        productItem.ChildItems.Add(new MenuItem("软件产品"));
        MenuItem serviceItem = new MenuItem("售后服务");
        Menu1.Items.Add(serviceItem);
        serviceItem.ChildItems.Add(new MenuItem("培训"));
        serviceItem.ChildItems.Add(new MenuItem("咨询"));
        serviceItem.ChildItems.Add(new MenuItem("技术支持"));
    }
}
