﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Server : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("<p>调用Execute方法之前</p>");
        Server.Execute("TestPage.aspx");
        Response.Write("<p>调用Excute方法之后</p>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write("<p>调用Transfer方法之前</p>");
        Server.Transfer("TestPage.aspx");
        Response.Write("<p>调用Transfer方法之后</p>");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Write("网页实际路径为：" + Server.MapPath("Server.aspx") + "<br>");
        Response.Write("根目录为：" + Server.MapPath("~/"));

    }
}
