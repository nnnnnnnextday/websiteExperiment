﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DynamicInsertTreeNode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TreeNode homeNode = new TreeNode();
        homeNode.Text = "首页";
        homeNode.ToolTip = "网站的首页";
        TreeView1.Nodes.Add(homeNode);
        TreeNode productItem = new TreeNode("产品分类");
        TreeView1.Nodes.Add(productItem);
        productItem.ChildNodes.Add(new TreeNode("硬件产品"));
        productItem.ChildNodes.Add(new TreeNode("软件产品"));
        TreeNode serviceItem = new TreeNode("售后服务");
        TreeView1.Nodes.Add(serviceItem);
        serviceItem.ChildNodes.Add(new TreeNode("培训"));
        serviceItem.ChildNodes.Add(new TreeNode("咨询"));
        serviceItem.ChildNodes.Add(new TreeNode("技术支持"));
    }
}
