﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Security;

public partial class _10_3 : System.Web.UI.Page
{
    private MembershipUserCollection m_userList; // 保存用户列表信息
    protected void Page_Load(object sender, EventArgs e)
    {
        lStatus.Text = "";
        m_userList = Membership.GetAllUsers();
        gvUserList.DataSource = m_userList; // 设置GridView控件数据源
        if (!IsPostBack)
            gvUserList.DataBind(); // 将数据源中数据绑定到GridView控件
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            // 用于描述 CreateUser 操作结果的枚举型数据
            MembershipCreateStatus status;
            Membership.CreateUser(tbUser.Text, tbPassword.Text,
                                                   tbEmail.Text, tbQ.Text, tbA.Text,
                                                   true, out status);
            if (status != MembershipCreateStatus.Success)
                lStatus.Text = "创建用户失败！";
            else
                lStatus.Text = "创建用户成功！";
            // 重新获得用户列表并刷新GridView
            m_userList = Membership.GetAllUsers();
            gvUserList.DataSource = m_userList;
            gvUserList.DataBind();
        }
        catch (Exception ex)
        {
            this.lStatus.Text = "创建用户失败！";
        }
    }
    protected void gvUserList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("DeleteUser"))
        {
            string userName = (string)gvUserList.DataKeys[0].Value; // 获取UserName字段
            Membership.DeleteUser(userName);
            // 重新获得用户列表并刷新GridView
            m_userList = Membership.GetAllUsers();
            gvUserList.DataSource = m_userList;
            gvUserList.DataBind();
        }
    }
}
