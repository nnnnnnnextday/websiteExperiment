﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _3_3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLog_Click(object sender, EventArgs e)
    {
        Response.BufferOutput = true   ;
        Response.Write("欢迎您访问本网站，您已通过身份验证！");
        if (txtPwd.Text == "123")
            Response.Flush();
        else
            Response.ClearContent();

    }
}
