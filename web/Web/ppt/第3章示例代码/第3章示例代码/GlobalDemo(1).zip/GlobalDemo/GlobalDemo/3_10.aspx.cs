﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class _3_10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //读取wen.config文件中的appSettings属性中名称为SiteInfoName的自定义配置信息
        Response.Write(ConfigurationManager.AppSettings["SiteInfoName"]);

    }
}
