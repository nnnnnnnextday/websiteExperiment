﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _3_2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DayOfWeek weekday = DateTime.Now.DayOfWeek;
        //(int)weekday为1-5，表示周一至周五；(int)weekday为0，表示周日；(int)weekday为6，表示周六
        if ((int)weekday >= 1 && (int)weekday <= 5)
        {
            Response.Write("今天是工作日，欢迎你的光临！");
        }
        else
        {
            Response.Write("今天是假日，十分遗憾，请在工作日再来!");
            Response.End();
            Response.Write("End后面的语句!");
        }

    }
}
