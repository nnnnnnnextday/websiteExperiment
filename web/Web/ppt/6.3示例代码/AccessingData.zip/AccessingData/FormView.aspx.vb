﻿
Partial Class AccessingData_FormView
    Inherits System.Web.UI.Page

End Class
